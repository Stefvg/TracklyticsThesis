<?php
/**
 * Created by PhpStorm.
 * User: stefvangils
 * Date: 31/10/15
 * Time: 16:27
 */

include_once '../../../../php/Database.php';
$conn = getDatabase();

$number = $_GET['number'];
$type = $_GET['type'];
$device = $_GET['device'];
$version = $_GET['version'];
$versionNumber = $_GET['versionNumber'];

$query = "SELECT DISTINCT value FROM Histogram_View WHERE type='$type' AND device ='$device' AND version='$version' ORDER BY value ASC";
$result = mysql_query($query);
if (!$result) {
    die('Invalid query: ' . mysql_error());
}


$array = array();

while ($row = mysql_fetch_assoc($result)) {
    $object['value'] = doubleval($row['value']);
    $object['versionNumber'] = $versionNumber;

    array_push($array, $object);
}
$output[$number] = $array;

echo(json_encode($output));


?>